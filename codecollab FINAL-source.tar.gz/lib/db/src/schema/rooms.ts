import { pgTable, text, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const roomsTable = pgTable("rooms", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  language: text("language").notNull(),
  leaderId: text("leader_id").notNull(),
  leaderName: text("leader_name").notNull(),
  code: text("code").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  activeUsers: integer("active_users").notNull().default(0),
});

export const insertRoomSchema = createInsertSchema(roomsTable).omit({ createdAt: true, activeUsers: true });
export type InsertRoom = z.infer<typeof insertRoomSchema>;
export type Room = typeof roomsTable.$inferSelect;
