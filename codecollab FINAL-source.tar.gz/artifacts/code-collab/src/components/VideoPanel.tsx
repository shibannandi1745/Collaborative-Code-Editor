import { useEffect, useRef, useState, useCallback } from 'react';
import { RoomUser } from '@/hooks/use-websocket';

interface VideoPanelProps {
  userId: string;
  users: RoomUser[];
  sendRtcSignal: (signal: object) => void;
  onRtcSignal: (handler: (msg: any) => void) => void;
}

const ICE_SERVERS = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
  ],
};

interface PeerEntry {
  pc: RTCPeerConnection;
  stream?: MediaStream;
}

export default function VideoPanel({ userId, users, sendRtcSignal, onRtcSignal }: VideoPanelProps) {
  const [isCameraOn, setIsCameraOn] = useState(false);
  const [isMicOn, setIsMicOn] = useState(true);
  const [remoteStreams, setRemoteStreams] = useState<Map<string, MediaStream>>(new Map());
  const localStreamRef = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const peersRef = useRef<Map<string, PeerEntry>>(new Map());

  const otherUsers = users.filter(u => u.id !== userId);

  // Attach incoming RTC signal handler
  useEffect(() => {
    onRtcSignal(handleSignal);
  }, [onRtcSignal]);

  async function createPeer(targetUserId: string, initiator: boolean): Promise<RTCPeerConnection> {
    const existing = peersRef.current.get(targetUserId);
    if (existing) return existing.pc;

    const pc = new RTCPeerConnection(ICE_SERVERS);

    peersRef.current.set(targetUserId, { pc });

    // Add local tracks if camera is on
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => {
        pc.addTrack(track, localStreamRef.current!);
      });
    }

    // On remote track
    pc.ontrack = (event) => {
      const stream = event.streams[0];
      setRemoteStreams(prev => new Map(prev).set(targetUserId, stream));
    };

    // ICE candidates
    pc.onicecandidate = (event) => {
      if (event.candidate) {
        sendRtcSignal({
          type: 'webrtc-ice-candidate',
          targetUserId,
          candidate: event.candidate,
        });
      }
    };

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
        pc.close();
        peersRef.current.delete(targetUserId);
        setRemoteStreams(prev => {
          const next = new Map(prev);
          next.delete(targetUserId);
          return next;
        });
      }
    };

    if (initiator) {
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      sendRtcSignal({
        type: 'webrtc-offer',
        targetUserId,
        sdp: offer,
      });
    }

    return pc;
  }

  async function handleSignal(msg: any) {
    const fromUserId: string = msg.fromUserId;
    if (!fromUserId) return;

    if (msg.type === 'webrtc-offer') {
      const pc = await createPeer(fromUserId, false);
      await pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      sendRtcSignal({
        type: 'webrtc-answer',
        targetUserId: fromUserId,
        sdp: answer,
      });

    } else if (msg.type === 'webrtc-answer') {
      const peer = peersRef.current.get(fromUserId);
      if (peer) {
        await peer.pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
      }

    } else if (msg.type === 'webrtc-ice-candidate') {
      const peer = peersRef.current.get(fromUserId);
      if (peer && msg.candidate) {
        try {
          await peer.pc.addIceCandidate(new RTCIceCandidate(msg.candidate));
        } catch (_) {}
      }
    }
  }

  async function startCamera() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: 320, height: 240 },
        audio: true,
      });
      localStreamRef.current = stream;
      if (localVideoRef.current) {
        localVideoRef.current.srcObject = stream;
      }
      setIsCameraOn(true);

      // Initiate calls with all existing users
      for (const u of otherUsers) {
        createPeer(u.id, true);
      }
    } catch (err) {
      console.error('Camera access error:', err);
      alert('Could not access camera/microphone. Please allow permissions.');
    }
  }

  function stopCamera() {
    localStreamRef.current?.getTracks().forEach(t => t.stop());
    localStreamRef.current = null;
    if (localVideoRef.current) localVideoRef.current.srcObject = null;
    setIsCameraOn(false);
    // Close all peers
    peersRef.current.forEach(({ pc }) => pc.close());
    peersRef.current.clear();
    setRemoteStreams(new Map());
  }

  function toggleMic() {
    if (localStreamRef.current) {
      localStreamRef.current.getAudioTracks().forEach(t => {
        t.enabled = !t.enabled;
      });
      setIsMicOn(prev => !prev);
    }
  }

  // When a new user joins and we have camera on, call them
  useEffect(() => {
    if (!isCameraOn) return;
    for (const u of otherUsers) {
      if (!peersRef.current.has(u.id)) {
        createPeer(u.id, true);
      }
    }
  }, [users, isCameraOn]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  return (
    <div className="flex flex-col h-full bg-[#1e1e1e] border-t border-border">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2 bg-[#252526] border-b border-border shrink-0">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
          Video Call
        </span>
        <div className="flex items-center gap-1">
          <button
            onClick={toggleMic}
            disabled={!isCameraOn}
            title={isMicOn ? "Mute" : "Unmute"}
            className={`p-1.5 rounded text-xs transition-colors ${
              !isCameraOn
                ? 'text-muted-foreground/40 cursor-not-allowed'
                : isMicOn
                ? 'text-green-400 hover:bg-white/10'
                : 'text-red-400 hover:bg-white/10'
            }`}
          >
            {isMicOn ? (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
              </svg>
            )}
          </button>
          <button
            onClick={isCameraOn ? stopCamera : startCamera}
            title={isCameraOn ? "Stop camera" : "Start camera"}
            className={`p-1.5 rounded text-xs transition-colors ${
              isCameraOn
                ? 'bg-red-600 hover:bg-red-700 text-white'
                : 'bg-primary hover:bg-primary/80 text-primary-foreground'
            }`}
          >
            {isCameraOn ? (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.069A1 1 0 0121 8.82v6.36a1 1 0 01-1.447.893L15 14M3 8a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.069A1 1 0 0121 8.82v6.36a1 1 0 01-1.447.893L15 14M3 8a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
              </svg>
            )}
          </button>
        </div>
      </div>

      {/* Video Grid */}
      <div className="flex-1 overflow-y-auto p-2 grid grid-cols-1 gap-2">
        {/* Local video */}
        <div className="relative rounded-lg overflow-hidden bg-[#2d2d2d] aspect-video">
          <video
            ref={localVideoRef}
            autoPlay
            muted
            playsInline
            className={`w-full h-full object-cover ${!isCameraOn ? 'hidden' : ''}`}
          />
          {!isCameraOn && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
              <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center text-lg font-bold text-primary">
                {users.find(u => u.id === userId)?.name?.charAt(0).toUpperCase() || 'Y'}
              </div>
              <span className="text-xs text-muted-foreground">Camera off</span>
            </div>
          )}
          <div className="absolute bottom-1 left-1 text-[10px] bg-black/60 text-white px-1.5 py-0.5 rounded">
            You {!isMicOn && '🔇'}
          </div>
        </div>

        {/* Remote videos */}
        {otherUsers.map(u => {
          const stream = remoteStreams.get(u.id);
          return (
            <RemoteVideo key={u.id} user={u} stream={stream} />
          );
        })}

        {otherUsers.length === 0 && (
          <div className="text-center text-xs text-muted-foreground py-4">
            No other users in this room yet.<br />Share the link to invite collaborators.
          </div>
        )}
      </div>
    </div>
  );
}

function RemoteVideo({ user, stream }: { user: RoomUser; stream?: MediaStream }) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  return (
    <div className="relative rounded-lg overflow-hidden bg-[#2d2d2d] aspect-video">
      {stream ? (
        <video
          ref={videoRef}
          autoPlay
          playsInline
          className="w-full h-full object-cover"
        />
      ) : (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold text-white"
            style={{ backgroundColor: user.color || '#555' }}
          >
            {user.name.charAt(0).toUpperCase()}
          </div>
          <span className="text-xs text-muted-foreground">Camera off</span>
        </div>
      )}
      <div className="absolute bottom-1 left-1 text-[10px] bg-black/60 text-white px-1.5 py-0.5 rounded">
        {user.name} {user.isLeader && '👑'}
      </div>
    </div>
  );
}
