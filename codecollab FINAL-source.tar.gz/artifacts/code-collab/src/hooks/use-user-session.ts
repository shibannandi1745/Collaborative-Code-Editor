import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';

interface UserSession {
  userId: string;
  userName: string;
}

export function useUserSession() {
  const [session, setSession] = useState<UserSession | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const storedId = localStorage.getItem('cc_userId');
    const storedName = localStorage.getItem('cc_userName');

    if (storedId && storedName) {
      setSession({ userId: storedId, userName: storedName });
    }
    setIsLoaded(true);
  }, []);

  const saveSession = (userName: string) => {
    let userId = localStorage.getItem('cc_userId');
    if (!userId) {
      userId = uuidv4();
      localStorage.setItem('cc_userId', userId);
    }
    
    localStorage.setItem('cc_userName', userName);
    setSession({ userId, userName });
    
    return { userId, userName };
  };

  const clearSession = () => {
    localStorage.removeItem('cc_userName');
    setSession(null);
  };

  return {
    session,
    isLoaded,
    saveSession,
    clearSession
  };
}
