import { useState, useEffect, useCallback, useRef } from 'react';

export interface RoomUser {
  id: string;
  name: string;
  color?: string;
  isLeader?: boolean;
}

interface UseWebSocketProps {
  roomId: string;
  userId: string;
  userName: string;
  onCodeUpdate?: (code: string) => void;
  onUsersUpdate?: (users: RoomUser[]) => void;
  onUserLeft?: (userId: string) => void;
  onInit?: (code: string, language: string, leaderId: string) => void;
  onRtcSignal?: (msg: any) => void;
  onKicked?: (reason: string) => void;
}

export function useWebSocket({
  roomId,
  userId,
  userName,
  onCodeUpdate,
  onUsersUpdate,
  onUserLeft,
  onInit,
  onRtcSignal,
}: UseWebSocketProps) {
  const [isConnected, setIsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectTimeoutRef = useRef<ReturnType<typeof setTimeout>>();

  // Use refs for callbacks so we don't recreate the WS on every render
  const onCodeUpdateRef = useRef(onCodeUpdate);
  const onUsersUpdateRef = useRef(onUsersUpdate);
  const onUserLeftRef = useRef(onUserLeft);
  const onInitRef = useRef(onInit);
  const onRtcSignalRef = useRef(onRtcSignal);

  useEffect(() => { onCodeUpdateRef.current = onCodeUpdate; }, [onCodeUpdate]);
  useEffect(() => { onUsersUpdateRef.current = onUsersUpdate; }, [onUsersUpdate]);
  useEffect(() => { onUserLeftRef.current = onUserLeft; }, [onUserLeft]);
  useEffect(() => { onInitRef.current = onInit; }, [onInit]);
  useEffect(() => { onRtcSignalRef.current = onRtcSignal; }, [onRtcSignal]);

  const connect = useCallback(() => {
    if (!roomId || !userId || !userName) return;

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/ws?roomId=${encodeURIComponent(roomId)}&userId=${encodeURIComponent(userId)}&userName=${encodeURIComponent(userName)}`;

    try {
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);

          switch (data.type) {
            case 'init':
              onInitRef.current?.(data.code, data.language, data.leaderId);
              break;
            case 'code-update':
              onCodeUpdateRef.current?.(data.code);
              break;
            case 'users-update':
              onUsersUpdateRef.current?.(data.users);
              break;
            case 'user-left':
              onUserLeftRef.current?.(data.userId);
              break;
            case 'webrtc-offer':
            case 'webrtc-answer':
            case 'webrtc-ice-candidate':
              onRtcSignalRef.current?.(data);
              break;
          }
        } catch (err) {
          console.error('Failed to parse WebSocket message', err);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        reconnectTimeoutRef.current = setTimeout(connect, 3000);
      };

      ws.onerror = () => {
        ws.close();
      };
    } catch (error) {
      console.error('Failed to establish WebSocket connection:', error);
    }
  }, [roomId, userId, userName]); // Only reconnect when identity changes

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectTimeoutRef.current);
      wsRef.current?.close();
    };
  }, [connect]);

  const sendCodeChange = useCallback((code: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type: 'code-change', code }));
    }
  }, []);

  const sendRtcSignal = useCallback((signal: object) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(signal));
    }
  }, []);

  return { isConnected, sendCodeChange, sendRtcSignal };
}
