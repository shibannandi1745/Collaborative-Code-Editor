import { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useLocation } from "wouter";
import Editor from "@monaco-editor/react";
import { motion, AnimatePresence } from "framer-motion";
import { useGetRoom, useExecuteCode } from "@workspace/api-client-react";
import { ExecuteRequestLanguage } from "@workspace/api-client-react";
import { useWebSocket, RoomUser } from "@/hooks/use-websocket";
import { useUserSession } from "@/hooks/use-user-session";
import { Icons, LanguageIcons } from "@/components/ui/icons";
import { useToast } from "@/hooks/use-toast";
import VideoPanel from "@/components/VideoPanel";

export default function RoomWorkspace() {
  const { roomId } = useParams<{ roomId: string }>();
  const [, setLocation] = useLocation();
  const { session, isLoaded } = useUserSession();
  const { toast } = useToast();

  const [code, setCode] = useState("");
  const [language, setLanguage] = useState<ExecuteRequestLanguage>("javascript");
  const [users, setUsers] = useState<RoomUser[]>([]);
  const [isTerminalOpen, setIsTerminalOpen] = useState(true);
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const [output, setOutput] = useState<{
    text: string;
    type: "stdout" | "stderr";
    time?: number;
    exitCode?: number;
  } | null>(null);

  // Prevent echoing remote code back to the server
  const suppressNextBroadcast = useRef(false);

  // RTC signal handler ref — VideoPanel registers its handler here
  const rtcSignalHandlerRef = useRef<((msg: any) => void) | null>(null);

  const { data: roomData, isLoading: isLoadingRoom, error: roomError } = useGetRoom(
    roomId || "",
    { query: { retry: 1, refetchOnWindowFocus: false } }
  );

  const executeMutation = useExecuteCode();

  // Callbacks using stable refs pattern — no reconnection on re-render
  const handleInit = useCallback((initCode: string, initLang: string) => {
    setCode(initCode);
    setLanguage(initLang as ExecuteRequestLanguage);
  }, []);

  const handleCodeUpdate = useCallback((newCode: string) => {
    suppressNextBroadcast.current = true;
    setCode(newCode);
  }, []);

  const handleUsersUpdate = useCallback((updatedUsers: RoomUser[]) => {
    setUsers(updatedUsers);
  }, []);

  const handleUserLeft = useCallback((leftUserId: string) => {
    setUsers(prev => prev.filter(u => u.id !== leftUserId));
  }, []);

  const handleRtcSignal = useCallback((msg: any) => {
    rtcSignalHandlerRef.current?.(msg);
  }, []);

  const { isConnected, sendCodeChange, sendRtcSignal } = useWebSocket({
    roomId: roomId || "",
    userId: session?.userId || "",
    userName: session?.userName || "",
    onInit: handleInit,
    onCodeUpdate: handleCodeUpdate,
    onUsersUpdate: handleUsersUpdate,
    onUserLeft: handleUserLeft,
    onRtcSignal: handleRtcSignal,
  });

  // Redirect to home if no session
  useEffect(() => {
    if (isLoaded && !session) {
      toast({ title: "Please enter your name to join" });
      setLocation("/");
    }
  }, [isLoaded, session]);

  const handleEditorChange = (value: string | undefined) => {
    const newValue = value || "";
    setCode(newValue);
    if (suppressNextBroadcast.current) {
      suppressNextBroadcast.current = false;
      return;
    }
    sendCodeChange(newValue);
  };

  const handleRunCode = async () => {
    if (!code.trim()) return;
    setIsTerminalOpen(true);
    setOutput({ text: "Executing...", type: "stdout" });
    try {
      const result = await executeMutation.mutateAsync({
        data: { code, language, roomId },
      });
      const hasError = result.exitCode !== 0;
      const text = hasError
        ? (result.error || result.output || "Execution failed")
        : (result.output || result.error || "No output");
      setOutput({
        text,
        type: hasError ? "stderr" : "stdout",
        time: result.executionTime,
        exitCode: result.exitCode,
      });
    } catch (error: any) {
      setOutput({ text: `Execution failed: ${error.message}`, type: "stderr" });
    }
  };

  const copyShareLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast({ title: "Link copied!", description: "Share this link with others to collaborate." });
  };

  if (!isLoaded || !session) return null;

  if (isLoadingRoom) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background text-foreground">
        <div className="flex flex-col items-center gap-4">
          <Icons.spinner className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Joining workspace...</p>
        </div>
      </div>
    );
  }

  if (roomError) {
    return (
      <div className="h-screen w-full flex flex-col items-center justify-center bg-background text-foreground">
        <Icons.error className="w-12 h-12 text-destructive mb-4" />
        <h2 className="text-2xl font-bold mb-2">Room not found</h2>
        <p className="text-muted-foreground mb-6">The room might have expired or the ID is incorrect.</p>
        <button
          onClick={() => setLocation("/")}
          className="px-6 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
        >
          Return Home
        </button>
      </div>
    );
  }

  const fileExt: Record<string, string> = {
    javascript: "js", typescript: "ts", python: "py", java: "java", cpp: "cpp",
  };
  const LangIcon = LanguageIcons[language] || Icons.fileCode;

  return (
    <div className="flex h-screen w-full flex-col bg-background text-foreground overflow-hidden font-sans">

      {/* Top Toolbar */}
      <header className="h-12 border-b border-border flex items-center justify-between px-4 bg-card shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-primary font-bold">
            <Icons.terminal className="w-5 h-5" />
            <span className="hidden sm:inline tracking-tight">CodeCollab</span>
          </div>
          <div className="h-4 w-px bg-border hidden sm:block" />
          <div className="flex items-center gap-2 bg-background/50 px-3 py-1 rounded-md border border-border/50 text-sm max-w-[200px] overflow-hidden">
            <span className="text-muted-foreground shrink-0">Room:</span>
            <span className="font-mono text-xs truncate">{roomData?.name || roomId}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Live/Offline indicator */}
          <div
            className="hidden sm:flex items-center gap-1.5 px-2"
            title={isConnected ? "Connected — changes sync in real-time" : "Reconnecting..."}
          >
            {isConnected ? (
              <>
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-green-500" />
                </span>
                <span className="text-xs text-muted-foreground">Live</span>
              </>
            ) : (
              <>
                <Icons.spinner className="w-2.5 h-2.5 animate-spin text-yellow-400" />
                <span className="text-xs text-yellow-400">Reconnecting</span>
              </>
            )}
          </div>

          {/* Video toggle */}
          <button
            onClick={() => setIsVideoOpen(v => !v)}
            title="Toggle video call"
            className={`flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-colors ${
              isVideoOpen
                ? "bg-primary text-primary-foreground"
                : "bg-secondary hover:bg-secondary/80 text-secondary-foreground"
            }`}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.069A1 1 0 0121 8.82v6.36a1 1 0 01-1.447.893L15 14M3 8a2 2 0 012-2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2V8z" />
            </svg>
            <span className="hidden sm:inline">{isVideoOpen ? "Hide Camera" : "Camera"}</span>
          </button>

          <button
            onClick={copyShareLink}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm bg-secondary hover:bg-secondary/80 text-secondary-foreground rounded-md transition-colors"
          >
            <Icons.share className="w-4 h-4" />
            <span className="hidden sm:inline">Share</span>
          </button>

          <button
            onClick={handleRunCode}
            disabled={executeMutation.isPending}
            className="flex items-center gap-1.5 px-4 py-1.5 text-sm bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors shadow-sm disabled:opacity-70"
          >
            {executeMutation.isPending ? (
              <Icons.spinner className="w-4 h-4 animate-spin" />
            ) : (
              <Icons.play className="w-4 h-4 fill-current" />
            )}
            <span className="font-medium">Run</span>
          </button>
        </div>
      </header>

      {/* Main Workspace */}
      <div className="flex flex-1 overflow-hidden">

        {/* Left Sidebar — Explorer + Collaborators */}
        <aside className="w-56 border-r border-border bg-sidebar flex flex-col shrink-0 hidden md:flex">
          <div className="px-3 py-2 uppercase text-[10px] font-bold tracking-wider text-muted-foreground border-b border-border/50">
            Explorer
          </div>

          <div className="p-2 border-b border-border/50">
            <div className="flex items-center gap-2 px-2 py-1.5 bg-primary/10 text-primary rounded-md text-sm font-medium">
              <LangIcon className="w-4 h-4 shrink-0" />
              <span className="truncate">main.{fileExt[language] || "txt"}</span>
            </div>
          </div>

          <div className="px-3 py-2 uppercase text-[10px] font-bold tracking-wider text-muted-foreground flex justify-between items-center">
            <span>Collaborators ({users.length})</span>
            <Icons.users className="w-3 h-3" />
          </div>

          <div className="flex-1 overflow-y-auto p-2 space-y-0.5">
            {users.map(user => (
              <div
                key={user.id}
                className="flex items-center justify-between px-2 py-1.5 hover:bg-white/5 rounded-md text-sm"
              >
                <div className="flex items-center gap-2 overflow-hidden">
                  {/* Online dot */}
                  <div className="relative shrink-0">
                    <div
                      className="w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold text-white"
                      style={{ backgroundColor: user.color || "#555" }}
                    >
                      {user.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 bg-green-500 border border-sidebar rounded-full" />
                  </div>
                  <span className="truncate text-foreground/80">
                    {user.name}
                    {user.id === session.userId && (
                      <span className="text-muted-foreground ml-1 text-[10px]">(you)</span>
                    )}
                  </span>
                </div>
                {user.isLeader && (
                  <Icons.leader className="w-3.5 h-3.5 text-yellow-500 shrink-0" title="Room Leader" />
                )}
              </div>
            ))}
            {users.length === 0 && (
              <p className="text-xs text-muted-foreground px-2 py-2">Connecting...</p>
            )}
          </div>
        </aside>

        {/* Editor + Terminal */}
        <div className="flex flex-col flex-1 min-w-0 bg-[#1e1e1e]">
          {/* Tab bar */}
          <div className="h-9 flex items-center bg-[#1e1e1e] border-b border-border/40 shrink-0">
            <div className="flex items-center h-full px-4 border-r border-border/40 text-foreground min-w-[120px] max-w-[200px]">
              <LangIcon className="w-3.5 h-3.5 mr-2 text-primary shrink-0" />
              <span className="text-sm truncate">main.{fileExt[language] || "txt"}</span>
            </div>
          </div>

          {/* Monaco Editor */}
          <div className="flex-1 relative">
            <Editor
              height="100%"
              language={language}
              theme="vs-dark"
              value={code}
              onChange={handleEditorChange}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                fontFamily: "Fira Code, Menlo, Monaco, Consolas, monospace",
                fontLigatures: true,
                padding: { top: 16, bottom: 16 },
                scrollBeyondLastLine: false,
                smoothScrolling: true,
                cursorBlinking: "smooth",
                cursorSmoothCaretAnimation: "on",
                renderWhitespace: "selection",
              }}
            />
          </div>

          {/* Terminal / Output Panel */}
          <AnimatePresence initial={false}>
            {isTerminalOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "28%", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: "easeOut" }}
                className="border-t border-border flex flex-col bg-[#1e1e1e] shrink-0"
              >
                <div className="h-9 flex items-center justify-between px-4 border-b border-border/50 bg-[#252526] shrink-0">
                  <div className="flex items-center gap-4 h-full">
                    <span className="text-xs uppercase tracking-wider font-medium text-foreground border-b border-primary h-full flex items-center">
                      Output
                    </span>
                  </div>
                  <button
                    onClick={() => setIsTerminalOpen(false)}
                    className="text-muted-foreground hover:text-white p-1 rounded transition-colors"
                  >
                    <Icons.close className="w-4 h-4" />
                  </button>
                </div>

                <div className="flex-1 overflow-auto p-4 font-mono text-sm">
                  {!output ? (
                    <span className="text-muted-foreground italic">
                      Press Run to execute code and see output here.
                    </span>
                  ) : executeMutation.isPending ? (
                    <div className="flex items-center gap-2 text-primary">
                      <Icons.spinner className="w-4 h-4 animate-spin" />
                      Executing...
                    </div>
                  ) : (
                    <div>
                      <pre
                        className={`whitespace-pre-wrap ${
                          output.type === "stderr"
                            ? "text-red-400"
                            : "text-[#cccccc]"
                        }`}
                      >
                        {output.text}
                      </pre>
                      {output.time !== undefined && (
                        <div className="mt-3 flex items-center gap-4 text-xs text-muted-foreground border-t border-border/30 pt-2">
                          <span className={output.exitCode === 0 ? "text-green-400" : "text-red-400"}>
                            Exit {output.exitCode ?? 0}
                          </span>
                          <span>{output.time.toFixed(1)}ms</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Right panel — Video */}
        <AnimatePresence>
          {isVideoOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 220, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="border-l border-border shrink-0 overflow-hidden"
            >
              <VideoPanel
                userId={session.userId}
                users={users}
                sendRtcSignal={sendRtcSignal}
                onRtcSignal={(handler) => { rtcSignalHandlerRef.current = handler; }}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Status Bar */}
      <footer className="h-6 bg-[#007acc] text-white flex items-center justify-between px-3 text-xs shrink-0 select-none">
        <div className="flex items-center gap-3 h-full">
          <div className="flex items-center gap-1 hover:bg-white/20 px-1.5 h-full transition-colors">
            <Icons.users className="w-3.5 h-3.5" />
            <span>{users.length} Online</span>
          </div>
          <div className="flex items-center gap-1 hover:bg-white/20 px-1.5 h-full transition-colors">
            {isConnected ? (
              <><Icons.check className="w-3.5 h-3.5" /><span>Synced</span></>
            ) : (
              <><Icons.spinner className="w-3.5 h-3.5 animate-spin" /><span>Reconnecting</span></>
            )}
          </div>
        </div>
        <div className="flex items-center gap-3 h-full">
          <span className="hover:bg-white/20 px-1.5 h-full flex items-center uppercase">{language}</span>
          <span className="hover:bg-white/20 px-1.5 h-full flex items-center">UTF-8</span>
          <button
            onClick={() => setIsTerminalOpen(t => !t)}
            className="hover:bg-white/20 px-1.5 h-full transition-colors flex items-center"
            title="Toggle output panel"
          >
            <Icons.terminal className="w-3.5 h-3.5" />
          </button>
        </div>
      </footer>
    </div>
  );
}
