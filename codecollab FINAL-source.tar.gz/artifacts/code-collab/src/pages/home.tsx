import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { useCreateRoom } from "@workspace/api-client-react";
import { useUserSession } from "@/hooks/use-user-session";
import { Icons } from "@/components/ui/icons";
import { useToast } from "@/hooks/use-toast";
import { CreateRoomRequestLanguage } from "@workspace/api-client-react";

export default function Home() {
  const [, setLocation] = useLocation();
  const { session, isLoaded, saveSession } = useUserSession();
  const { toast } = useToast();
  
  const [activeTab, setActiveTab] = useState<"create" | "join">("create");
  const [userName, setUserName] = useState("");
  const [roomName, setRoomName] = useState("");
  const [joinRoomId, setJoinRoomId] = useState("");
  const [language, setLanguage] = useState<CreateRoomRequestLanguage>(CreateRoomRequestLanguage.javascript);
  
  const createRoomMutation = useCreateRoom();

  useEffect(() => {
    if (session?.userName) {
      setUserName(session.userName);
    }
  }, [session]);

  const handleCreateRoom = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !roomName.trim()) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }

    const { userName: savedName } = saveSession(userName);

    try {
      const room = await createRoomMutation.mutateAsync({
        data: {
          name: roomName,
          language,
          leaderName: savedName
        }
      });
      
      toast({ title: "Room created successfully!" });
      setLocation(`/room/${room.id}`);
    } catch (error: any) {
      toast({ 
        title: "Failed to create room", 
        description: error.message || "Unknown error occurred",
        variant: "destructive" 
      });
    }
  };

  const handleJoinRoom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim() || !joinRoomId.trim()) {
      toast({ title: "Please fill in all fields", variant: "destructive" });
      return;
    }

    // Extract ID if a full URL was pasted
    let idToJoin = joinRoomId;
    try {
      if (joinRoomId.includes('/room/')) {
        const url = new URL(joinRoomId);
        const parts = url.pathname.split('/');
        idToJoin = parts[parts.length - 1];
      }
    } catch (e) {
      // Not a valid URL, assume it's just the ID
    }

    saveSession(userName);
    setLocation(`/room/${idToJoin}`);
  };

  if (!isLoaded) return null;

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-background">
      {/* Background Image & Effects */}
      <div className="absolute inset-0 z-0">
        <img 
          src={`${import.meta.env.BASE_URL}images/hero-bg.png`} 
          alt="Hero background" 
          className="w-full h-full object-cover opacity-30 mix-blend-screen"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-transparent to-transparent opacity-60" />
      </div>

      <div className="relative z-10 w-full max-w-md px-6">
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col items-center mb-10"
        >
          <div className="w-20 h-20 mb-4 rounded-2xl bg-gradient-to-tr from-primary/20 to-primary/5 p-4 border border-primary/20 shadow-[0_0_30px_rgba(14,99,156,0.3)]">
            <img 
              src={`${import.meta.env.BASE_URL}images/logo.png`} 
              alt="CodeCollab Logo" 
              className="w-full h-full object-contain"
            />
          </div>
          <h1 className="text-4xl font-bold tracking-tight text-white mb-2">CodeCollab</h1>
          <p className="text-muted-foreground text-center">
            Real-time collaborative coding in your browser.
          </p>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="glass-panel rounded-2xl overflow-hidden shadow-2xl"
        >
          <div className="flex border-b border-border/50">
            <button
              className={`flex-1 py-4 text-sm font-medium transition-colors ${
                activeTab === "create" 
                  ? "text-primary border-b-2 border-primary bg-primary/5" 
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              }`}
              onClick={() => setActiveTab("create")}
            >
              Create Room
            </button>
            <button
              className={`flex-1 py-4 text-sm font-medium transition-colors ${
                activeTab === "join" 
                  ? "text-primary border-b-2 border-primary bg-primary/5" 
                  : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              }`}
              onClick={() => setActiveTab("join")}
            >
              Join Room
            </button>
          </div>

          <div className="p-6">
            {activeTab === "create" ? (
              <form onSubmit={handleCreateRoom} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full bg-input/50 border border-border/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground/50"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
                    Room Name
                  </label>
                  <input
                    type="text"
                    value={roomName}
                    onChange={(e) => setRoomName(e.target.value)}
                    placeholder="e.g. Interview Prep"
                    className="w-full bg-input/50 border border-border/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground/50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
                    Language
                  </label>
                  <div className="relative">
                    <select
                      value={language}
                      onChange={(e) => setLanguage(e.target.value as CreateRoomRequestLanguage)}
                      className="w-full bg-input/50 border border-border/50 rounded-lg px-4 py-3 text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all text-foreground"
                    >
                      <option value="javascript">JavaScript</option>
                      <option value="typescript">TypeScript</option>
                      <option value="python">Python</option>
                      <option value="java">Java</option>
                      <option value="cpp">C++</option>
                    </select>
                    <Icons.chevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={createRoomMutation.isPending}
                  className="w-full mt-6 bg-primary hover:bg-primary/90 text-primary-foreground font-medium rounded-lg px-4 py-3 flex items-center justify-center transition-all shadow-lg shadow-primary/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {createRoomMutation.isPending ? (
                    <Icons.spinner className="w-5 h-5 animate-spin" />
                  ) : (
                    <>
                      <Icons.fileCode className="w-4 h-4 mr-2" />
                      Create Workspace
                    </>
                  )}
                </button>
              </form>
            ) : (
              <form onSubmit={handleJoinRoom} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
                    Your Name
                  </label>
                  <input
                    type="text"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                    placeholder="e.g. Alex"
                    className="w-full bg-input/50 border border-border/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground/50"
                  />
                </div>
                
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5 uppercase tracking-wider">
                    Room ID or Link
                  </label>
                  <input
                    type="text"
                    value={joinRoomId}
                    onChange={(e) => setJoinRoomId(e.target.value)}
                    placeholder="Paste link or ID here"
                    className="w-full bg-input/50 border border-border/50 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition-all placeholder:text-muted-foreground/50"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full mt-6 bg-secondary hover:bg-secondary/80 text-secondary-foreground font-medium rounded-lg px-4 py-3 flex items-center justify-center transition-all disabled:opacity-50 disabled:cursor-not-allowed border border-border"
                >
                  <Icons.users className="w-4 h-4 mr-2" />
                  Join Workspace
                </button>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
