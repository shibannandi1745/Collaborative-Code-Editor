import { exec } from "child_process";
import { writeFile, mkdir } from "fs/promises";
import { join } from "path";
import { tmpdir } from "os";
import { promisify } from "util";

const execAsync = promisify(exec);

interface ExecutionResult {
  output: string;
  error?: string;
  exitCode: number;
  executionTime: number;
}

async function runCmd(cmd: string, timeoutMs = 12000): Promise<ExecutionResult> {
  const start = Date.now();
  try {
    const { stdout, stderr } = await execAsync(cmd, {
      timeout: timeoutMs,
      maxBuffer: 1024 * 512,
    });
    return {
      output: stdout || "",
      error: stderr || undefined,
      exitCode: 0,
      executionTime: Date.now() - start,
    };
  } catch (err: any) {
    return {
      output: err.stdout || "",
      error: err.stderr || err.message || "Execution timed out or failed",
      exitCode: typeof err.code === "number" ? err.code : 1,
      executionTime: Date.now() - start,
    };
  }
}

export async function executeCode(code: string, language: string): Promise<ExecutionResult> {
  const tmpDir = join(tmpdir(), `cc-${Date.now()}-${Math.random().toString(36).slice(2)}`);
  await mkdir(tmpDir, { recursive: true });

  try {
    switch (language) {
      case "javascript": {
        const file = join(tmpDir, "main.js");
        await writeFile(file, code, "utf-8");
        return await runCmd(`node "${file}"`);
      }

      case "typescript": {
        const file = join(tmpDir, "main.ts");
        await writeFile(file, code, "utf-8");
        // Node 22+ supports stripping TypeScript types natively
        return await runCmd(`node --experimental-strip-types "${file}" 2>&1`);
      }

      case "python": {
        const file = join(tmpDir, "main.py");
        await writeFile(file, code, "utf-8");
        return await runCmd(`python3 "${file}"`);
      }

      case "java": {
        const classMatch = code.match(/public\s+class\s+(\w+)/);
        const className = classMatch ? classMatch[1] : "Main";
        const javaFile = join(tmpDir, `${className}.java`);
        await writeFile(javaFile, code, "utf-8");

        const compileResult = await runCmd(`javac "${javaFile}" -d "${tmpDir}"`);
        if (compileResult.exitCode !== 0) {
          return {
            output: compileResult.output,
            error: compileResult.error || compileResult.output,
            exitCode: compileResult.exitCode,
            executionTime: compileResult.executionTime,
          };
        }
        return await runCmd(`java -cp "${tmpDir}" ${className}`, 15000);
      }

      case "cpp": {
        const srcFile = join(tmpDir, "main.cpp");
        const outFile = join(tmpDir, "main_out");
        await writeFile(srcFile, code, "utf-8");

        const compileResult = await runCmd(`g++ -o "${outFile}" "${srcFile}" -std=c++17 2>&1`);
        if (compileResult.exitCode !== 0) {
          return {
            output: compileResult.output,
            error: compileResult.error || compileResult.output,
            exitCode: compileResult.exitCode,
            executionTime: compileResult.executionTime,
          };
        }
        return await runCmd(`"${outFile}"`, 10000);
      }

      default:
        return {
          output: "",
          error: `Unsupported language: ${language}`,
          exitCode: 1,
          executionTime: 0,
        };
    }
  } finally {
    execAsync(`rm -rf "${tmpDir}"`).catch(() => {});
  }
}
