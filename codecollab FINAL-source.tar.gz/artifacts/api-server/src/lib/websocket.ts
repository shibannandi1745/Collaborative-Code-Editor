import { WebSocket, WebSocketServer } from "ws";
import { IncomingMessage } from "http";
import { db, roomsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

interface ConnectedUser {
  id: string;
  name: string;
  color: string;
  ws: WebSocket;
  roomId: string;
}

const USER_COLORS = [
  "#4FC3F7", "#81C784", "#FFB74D", "#F48FB1",
  "#CE93D8", "#80DEEA", "#FFCC80", "#A5D6A7",
  "#90CAF9", "#EF9A9A",
];

const rooms = new Map<string, Set<ConnectedUser>>();
const users = new Map<WebSocket, ConnectedUser>();
// roomId -> leaderId
const roomLeaders = new Map<string, string>();

function getUserColor(roomId: string): string {
  const roomUsers = rooms.get(roomId);
  const usedColors = roomUsers ? Array.from(roomUsers).map(u => u.color) : [];
  const available = USER_COLORS.filter(c => !usedColors.includes(c));
  return available.length > 0 ? available[0] : USER_COLORS[Math.floor(Math.random() * USER_COLORS.length)];
}

function getRoomUserList(roomId: string) {
  const roomUsers = rooms.get(roomId);
  const leaderId = roomLeaders.get(roomId);
  if (!roomUsers) return [];
  return Array.from(roomUsers).map(u => ({
    id: u.id,
    name: u.name,
    color: u.color,
    isLeader: u.id === leaderId,
  }));
}

function broadcast(roomId: string, message: object, excludeWs?: WebSocket) {
  const roomUsers = rooms.get(roomId);
  if (!roomUsers) return;
  const data = JSON.stringify(message);
  for (const user of roomUsers) {
    if (user.ws !== excludeWs && user.ws.readyState === WebSocket.OPEN) {
      user.ws.send(data);
    }
  }
}

function broadcastAll(roomId: string, message: object) {
  broadcast(roomId, message, undefined);
}

// Forward a signaling message to a specific target user
function sendToUser(roomId: string, targetUserId: string, message: object) {
  const roomUsers = rooms.get(roomId);
  if (!roomUsers) return;
  const data = JSON.stringify(message);
  for (const user of roomUsers) {
    if (user.id === targetUserId && user.ws.readyState === WebSocket.OPEN) {
      user.ws.send(data);
      break;
    }
  }
}

export function setupWebSocket(wss: WebSocketServer) {
  wss.on("connection", (ws: WebSocket, req: IncomingMessage) => {
    const url = new URL(req.url || "", `http://localhost`);
    const roomId = url.searchParams.get("roomId") || "";
    const userId = url.searchParams.get("userId") || "";
    const userName = url.searchParams.get("userName") || "Anonymous";

    if (!roomId || !userId) {
      ws.close(1008, "Missing roomId or userId");
      return;
    }

    const color = getUserColor(roomId);
    const user: ConnectedUser = { id: userId, name: userName, color, ws, roomId };

    if (!rooms.has(roomId)) {
      rooms.set(roomId, new Set());
    }
    rooms.get(roomId)!.add(user);
    users.set(ws, user);

    // Load leader from DB if not cached
    if (!roomLeaders.has(roomId)) {
      db.select().from(roomsTable).where(eq(roomsTable.id, roomId)).then(([room]) => {
        if (room) roomLeaders.set(roomId, room.leaderId);
      }).catch(() => {});
    }

    // Update active users count in DB
    db.update(roomsTable)
      .set({ activeUsers: rooms.get(roomId)!.size })
      .where(eq(roomsTable.id, roomId))
      .catch(() => {});

    // Send current room code + leader info to new user
    db.select().from(roomsTable).where(eq(roomsTable.id, roomId)).then(([room]) => {
      if (room && ws.readyState === WebSocket.OPEN) {
        // Cache leader
        roomLeaders.set(roomId, room.leaderId);
        ws.send(JSON.stringify({
          type: "init",
          code: room.code,
          language: room.language,
          leaderId: room.leaderId,
        }));
        // Send fresh user list now that leader is known
        broadcastAll(roomId, { type: "users-update", users: getRoomUserList(roomId) });
      }
    }).catch(() => {});

    // Notify everyone of updated user list
    broadcastAll(roomId, { type: "users-update", users: getRoomUserList(roomId) });

    ws.on("message", async (data) => {
      try {
        const msg = JSON.parse(data.toString());

        if (msg.type === "code-change") {
          const newCode = msg.code ?? "";
          await db.update(roomsTable)
            .set({ code: newCode })
            .where(eq(roomsTable.id, roomId));
          broadcast(roomId, { type: "code-update", code: newCode, userId }, ws);

        } else if (msg.type === "kick") {
          // Only the leader can kick
          const leaderId = roomLeaders.get(roomId);
          if (userId !== leaderId) return;
          const targetId: string = msg.targetUserId;
          if (!targetId || targetId === userId) return;
          const roomUsers = rooms.get(roomId);
          if (!roomUsers) return;
          for (const u of roomUsers) {
            if (u.id === targetId) {
              // Tell the target they've been kicked before closing
              if (u.ws.readyState === WebSocket.OPEN) {
                u.ws.send(JSON.stringify({ type: "kicked", reason: "Removed by room admin" }));
              }
              setTimeout(() => u.ws.close(), 200);
              break;
            }
          }

        } else if (
          msg.type === "webrtc-offer" ||
          msg.type === "webrtc-answer" ||
          msg.type === "webrtc-ice-candidate"
        ) {
          // WebRTC signaling: forward to specific target
          if (msg.targetUserId) {
            sendToUser(roomId, msg.targetUserId, {
              ...msg,
              fromUserId: userId,
            });
          }
        }
      } catch (_) {}
    });

    ws.on("close", () => {
      const roomUsers = rooms.get(roomId);
      if (roomUsers) {
        roomUsers.delete(user);
        if (roomUsers.size === 0) {
          rooms.delete(roomId);
          roomLeaders.delete(roomId);
        } else {
          broadcastAll(roomId, { type: "users-update", users: getRoomUserList(roomId) });
          // Notify others that this user left (for WebRTC cleanup)
          broadcastAll(roomId, { type: "user-left", userId });
        }
        db.update(roomsTable)
          .set({ activeUsers: roomUsers.size })
          .where(eq(roomsTable.id, roomId))
          .catch(() => {});
      }
      users.delete(ws);
    });

    ws.on("error", () => {
      ws.close();
    });
  });
}
