import { Router, type IRouter } from "express";
import { ExecuteCodeBody, ExecuteCodeResponse } from "@workspace/api-zod";
import { executeCode } from "../lib/executor.js";

const router: IRouter = Router();

router.post("/execute", async (req, res): Promise<void> => {
  const parsed = ExecuteCodeBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { code, language } = parsed.data;

  const result = await executeCode(code, language);

  res.json(ExecuteCodeResponse.parse({
    output: result.output,
    error: result.error,
    exitCode: result.exitCode,
    executionTime: result.executionTime,
  }));
});

export default router;
