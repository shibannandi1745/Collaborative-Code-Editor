import { Router, type IRouter } from "express";
import { db, roomsTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { randomUUID } from "crypto";
import { CreateRoomBody, GetRoomParams, GetRoomResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.post("/rooms", async (req, res): Promise<void> => {
  const parsed = CreateRoomBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: parsed.error.message });
    return;
  }

  const { name, language, leaderName } = parsed.data;
  const id = randomUUID();
  const leaderId = randomUUID();

  const [room] = await db.insert(roomsTable).values({
    id,
    name,
    language,
    leaderId,
    leaderName,
    code: getDefaultCode(language),
  }).returning();

  res.status(201).json(GetRoomResponse.parse(room));
});

router.get("/rooms/:roomId", async (req, res): Promise<void> => {
  const raw = Array.isArray(req.params.roomId) ? req.params.roomId[0] : req.params.roomId;
  const params = GetRoomParams.safeParse({ roomId: raw });
  if (!params.success) {
    res.status(400).json({ message: "Invalid room ID" });
    return;
  }

  const [room] = await db.select().from(roomsTable).where(eq(roomsTable.id, params.data.roomId));

  if (!room) {
    res.status(404).json({ message: "Room not found" });
    return;
  }

  res.json(GetRoomResponse.parse(room));
});

function getDefaultCode(language: string): string {
  switch (language) {
    case "javascript":
      return `// Welcome to CodeCollab!\n// JavaScript environment\n\nconsole.log("Hello, World!");\n\n// Start coding here...\nconst message = "Collaborative coding is fun!";\nconsole.log(message);\n`;
    case "typescript":
      return `// Welcome to CodeCollab!\n// TypeScript environment\n\nconst greet = (name: string): string => {\n  return \`Hello, \${name}!\`;\n};\n\nconsole.log(greet("World"));\n`;
    case "python":
      return `# Welcome to CodeCollab!\n# Python environment\n\ndef greet(name: str) -> str:\n    return f"Hello, {name}!"\n\nprint(greet("World"))\n\n# Start coding here...\n`;
    case "java":
      return `// Welcome to CodeCollab!\n// Java environment\n\npublic class Main {\n    public static void main(String[] args) {\n        System.out.println("Hello, World!");\n        \n        // Start coding here...\n    }\n}\n`;
    case "cpp":
      return `// Welcome to CodeCollab!\n// C++ environment\n\n#include <iostream>\n#include <string>\n\nint main() {\n    std::cout << "Hello, World!" << std::endl;\n    \n    // Start coding here...\n    \n    return 0;\n}\n`;
    default:
      return "// Start coding here...\n";
  }
}

export default router;
