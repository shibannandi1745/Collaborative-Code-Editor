import { Router, type IRouter } from "express";
import healthRouter from "./health";
import roomsRouter from "./rooms";
import executeRouter from "./execute";

const router: IRouter = Router();

router.use(healthRouter);
router.use(roomsRouter);
router.use(executeRouter);

export default router;
